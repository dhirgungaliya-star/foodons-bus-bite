import './globals.css';

export const metadata = {
  title: 'Foodons',
  description: 'Food delivery for bus journeys',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
