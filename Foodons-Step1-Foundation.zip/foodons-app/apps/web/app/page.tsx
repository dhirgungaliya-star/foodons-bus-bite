'use client';

import { useState } from 'react';

type Route = { id: string; from: string; to: string; durationMinutes: number };

const fallbackRoutes: Route[] = [
  { id: 'route-mum-pun', from: 'Mumbai', to: 'Pune', durationMinutes: 210 },
  { id: 'route-pun-mum', from: 'Pune', to: 'Mumbai', durationMinutes: 210 },
  { id: 'route-mum-ahm', from: 'Mumbai', to: 'Ahmedabad', durationMinutes: 540 },
];

const apiBase = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000';

function duration(minutes: number) {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m ? `${h}h ${m}m` : `${h}h`;
}

export default function Home() {
  const [routes, setRoutes] = useState<Route[]>(fallbackRoutes);
  const [selected, setSelected] = useState<Route | null>(null);
  const [loading, setLoading] = useState(false);
  const [apiStatus, setApiStatus] = useState<'local' | 'connected'>('local');

  async function loadRoutes() {
    setLoading(true);
    try {
      const response = await fetch(`${apiBase}/api/v1/routes`, { cache: 'no-store' });
      if (!response.ok) throw new Error('API error');
      const data = (await response.json()) as Route[];
      setRoutes(data);
      setApiStatus('connected');
    } catch {
      setApiStatus('local');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="shell">
      <header className="topbar">
        <div className="logo"><span className="logoMark">F</span><span>Foodons</span></div>
        <button className="iconButton" onClick={loadRoutes} aria-label="Refresh routes">↻</button>
      </header>

      <main className="main">
        <section className="hero">
          <div className="eyebrow">Bus food delivery</div>
          <h1>Good food, right on your journey.</h1>
          <p>Foodons connects your bus journey with restaurants along the route, so your meal arrives at the right stop and seat.</p>

          <div className="journeyBox">
            <div className="field"><small>From</small><strong>{selected?.from ?? 'Mumbai'}</strong></div>
            <div className="field"><small>To</small><strong>{selected?.to ?? 'Pune'}</strong></div>
            <div className="field"><small>Travel date</small><strong>Today</strong></div>
            <button className="cta" onClick={loadRoutes}>{loading ? 'Checking…' : 'Find my bus'}</button>
          </div>
        </section>

        <section className="section">
          <div className="sectionHead"><h2>Popular journeys</h2><span>{apiStatus === 'connected' ? 'Live API' : 'Development data'}</span></div>
          <div className="cards">
            {routes.map(route => (
              <button className={`routeCard ${selected?.id === route.id ? 'selected' : ''}`} key={route.id} onClick={() => setSelected(route)}>
                <div className="routeTitle">{route.from} <span>→</span> {route.to}</div>
                <div className="meta">{duration(route.durationMinutes)} average journey</div>
                <div className="routeAction">Select journey →</div>
              </button>
            ))}
          </div>
        </section>

        <section className="section">
          <div className="sectionHead"><h2>Foodons foundation</h2><span>Step 1</span></div>
          <div className="featureGrid">
            <div className="feature"><b>Real backend</b><span>Customer UI is connected to a NestJS API boundary.</span></div>
            <div className="feature"><b>Database ready</b><span>PostgreSQL + Prisma models cover journeys, restaurants and orders.</span></div>
            <div className="feature"><b>Phone first</b><span>The customer experience is designed around small Android screens.</span></div>
            <div className="feature"><b>Built to expand</b><span>Bus APIs, GPS, restaurant partners and payments plug into separate services.</span></div>
          </div>
        </section>
      </main>

      <nav className="bottom"><button className="active">Home</button><button>Explore</button><button>Orders</button><button>Profile</button></nav>
    </div>
  );
}
