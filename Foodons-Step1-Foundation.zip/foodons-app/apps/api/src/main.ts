import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { Module, Controller, Get } from '@nestjs/common';

@Controller()
class AppController {
  @Get('/health')
  health() {
    return { ok: true, service: 'foodons-api', version: '0.1.0' };
  }

  @Get('/api/v1/routes')
  routes() {
    return [
      { id: 'route-mum-pun', from: 'Mumbai', to: 'Pune', durationMinutes: 210 },
      { id: 'route-pun-mum', from: 'Pune', to: 'Mumbai', durationMinutes: 210 },
      { id: 'route-mum-ahm', from: 'Mumbai', to: 'Ahmedabad', durationMinutes: 540 },
    ];
  }
}

@Module({ controllers: [AppController] })
class AppModule {}

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.enableCors({ origin: true, credentials: true });
  await app.listen(process.env.PORT ?? 4000);
}

bootstrap();
