import { PrismaClient, DietaryType } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  const operator = await prisma.busOperator.upsert({ where: { name: 'Foodons Demo Operator' }, update: {}, create: { name: 'Foodons Demo Operator' } });
  const route = await prisma.route.upsert({ where: { id: 'route-mum-pun' }, update: {}, create: { id: 'route-mum-pun', from: 'Mumbai', to: 'Pune' } });
  for (const [sequence, name] of ['Lonavala', 'Khandala', 'Pune Station'].entries()) {
    await prisma.routeStop.upsert({ where: { routeId_sequence: { routeId: route.id, sequence } }, update: {}, create: { routeId: route.id, sequence, name } });
  }
  const bus = await prisma.bus.upsert({ where: { registration: 'MH-14-AB-3737' }, update: {}, create: { registration: 'MH-14-AB-3737', operatorId: operator.id } });
  for (let row = 1; row <= 24; row++) for (let column = 1; column <= 2; column++) {
    await prisma.busSeat.upsert({ where: { id: `seed-seat-${row}-${column}` }, update: {}, create: { id: `seed-seat-${row}-${column}`, busId: bus.id, label: `${row}${column === 1 ? 'A' : 'B'}`, row, column } });
  }
  const restaurant = await prisma.restaurant.upsert({ where: { id: 'restaurant-green-leaf' }, update: {}, create: { id: 'restaurant-green-leaf', name: 'Green Leaf Kitchen', prepTimeMin: 30 } });
  await prisma.menuItem.upsert({ where: { id: 'menu-paneer-wrap' }, update: {}, create: { id: 'menu-paneer-wrap', restaurantId: restaurant.id, name: 'Paneer Tikka Wrap', price: 179, dietary: DietaryType.VEG } });
  console.log('Foodons seed completed');
}
main().finally(() => prisma.$disconnect());
