# Foodons

Production-oriented monorepo foundation for the Foodons bus-seat food-delivery platform.

## Stack
- Customer web/PWA: Next.js + React + TypeScript
- API: NestJS + TypeScript
- Database: PostgreSQL
- ORM: Prisma
- Development DB: Docker PostgreSQL

## Step 1 status
The foundation contains a phone-first customer web shell, a NestJS API boundary, and the core PostgreSQL/Prisma domain model.

## Run locally
Requirements: Node.js 22+, npm, Docker Desktop.

```bash
cp .env.example .env
npm install
npm run db:generate
docker compose up -d
npm run db:push
npm run db:seed
npm run dev:api
npm run dev:web
```

Open http://localhost:3000 on the phone or desktop browser. The web app reads journeys from the API at http://localhost:4000.

## Development rule
Use mock/local adapters while developing. Real SMS OTP, commercial bus APIs, maps, payment gateways, and production hosting can be plugged in later without changing the customer domain model.
